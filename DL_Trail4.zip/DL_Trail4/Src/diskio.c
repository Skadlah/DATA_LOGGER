#include "ff.h"
#include "diskio.h"
#include "tusb.h"

// The standard block size for USB flash drives
#define DISK_BLOCK_SIZE  512

DSTATUS disk_status (BYTE pdrv) {
    uint8_t const dev_addr = pdrv + 1;
    return tuh_msc_mounted(dev_addr) ? RES_OK : STA_NODISK;
}

DSTATUS disk_initialize (BYTE pdrv) {
    return disk_status(pdrv); // TinyUSB handles initialization automatically
}

DRESULT disk_read (BYTE pdrv, BYTE* buff, LBA_t sector, UINT count) {
    uint8_t const dev_addr = pdrv + 1;
    if ( !tuh_msc_mounted(dev_addr) ) return RES_NOTRDY;

    // Call TinyUSB's read function
    if ( tuh_msc_read10(dev_addr, 0, buff, sector, (uint16_t)count, NULL, 0) ) return RES_OK;
    return RES_ERROR;
}

DRESULT disk_write (BYTE pdrv, const BYTE* buff, LBA_t sector, UINT count) {
    uint8_t const dev_addr = pdrv + 1;
    if ( !tuh_msc_mounted(dev_addr) ) return RES_NOTRDY;

    // Call TinyUSB's write function
    if ( tuh_msc_write10(dev_addr, 0, buff, sector, (uint16_t)count, NULL, 0) ) return RES_OK;
    return RES_ERROR;
}

DRESULT disk_ioctl (BYTE pdrv, BYTE cmd, void* buff) {
    uint8_t const dev_addr = pdrv + 1;
    switch(cmd) {
        case CTRL_SYNC:
            return RES_OK;
        case GET_SECTOR_COUNT:
            *((DWORD*)buff) = tuh_msc_get_block_count(dev_addr, 0);
            return RES_OK;
        case GET_SECTOR_SIZE:
            *((WORD*)buff) = DISK_BLOCK_SIZE;
            return RES_OK;
        case GET_BLOCK_SIZE:
            *((DWORD*)buff) = 1;
            return RES_OK;
        default:
            return RES_PARERR;
    }
}
