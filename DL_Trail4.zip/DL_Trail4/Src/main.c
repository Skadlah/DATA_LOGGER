#include <stdint.h>
#include "STM32F407VETx.h"
#include "ff.h"      // FatFs Header
#include "tusb.h"    // TinyUSB Header

// ====================================================================
// GLOBAL VARIABLES & FLAGS
// ====================================================================
volatile uint32_t msTicks = 0;

// DMA Ping-Pong Flags
volatile uint8_t buffer_A_full = 0;
volatile uint8_t buffer_B_full = 0;

// FatFs Objects
static FATFS usb_fs;
static FIL   log_file;
FRESULT fres;

// Live Expressions Debug Dashboard
volatile uint8_t  usb_dev_addr       = 0;     // Tracks the physical address of the flash drive
volatile uint8_t  live_usb_connected = 0;     // 1 = Pen drive plugged in, 0 = Removed
volatile uint8_t  live_drive_mounted = 0;     // 1 = FatFs successfully mounted the drive
volatile uint8_t  live_file_created  = 0;     // 1 = static.csv is open/created, 0 = error
volatile uint8_t  live_write_success = 0;     // 1 = Last write was good, 0 = Write failed
volatile uint32_t live_bytes_written = 0;     // Running total of bytes saved to USB
volatile uint8_t  live_fatfs_error   = 0;     // Captures the FR_xxx error code if something crashes

// DMA Buffers
#define BUFFER_SIZE 512
uint8_t buffer_A[BUFFER_SIZE];
uint8_t buffer_B[BUFFER_SIZE];

// ====================================================================
// FUNCTION PROTOTYPES
// ====================================================================
void SystemClock_Config(void);
void SysTick_Init(void);
void Delay_ms(uint32_t ms);
void GPIO_Init(void);
void DMA_PingPong_Init(void);

// ====================================================================
// INITIALIZATION FUNCTIONS
// ====================================================================

void GPIO_Init(void) {
    // Enable clock for GPIOA (USB pins) and GPIOC (Battery pin)
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOCEN;

    // --- USB PINS (PA11 and PA12) ---
    GPIOA->MODER &= ~(GPIO_MODER_MODER11 | GPIO_MODER_MODER12);
    GPIOA->MODER |=  (GPIO_MODER_MODER11_1 | GPIO_MODER_MODER12_1); // Alt Function Mode
    GPIOA->OSPEEDR |= (GPIO_OSPEEDER_OSPEEDR11 | GPIO_OSPEEDER_OSPEEDR12); // Very High Speed
    GPIOA->AFR[1] &= ~(GPIO_AFRH_AFSEL11 | GPIO_AFRH_AFSEL12);
    GPIOA->AFR[1] |=  (0xA << 12) | (0xA << 16); // Map to AF10 (USB_FS)

    // --- BATTERY SENSING PIN (PC3) ---
    // Note: If you changed this to Pin 34 as mentioned previously, update the port/pin here
    GPIOC->MODER &= ~(GPIO_MODER_MODER3); // Input Mode
    GPIOC->PUPDR &= ~(GPIO_PUPDR_PUPDR3);
    GPIOC->PUPDR |=  (GPIO_PUPDR_PUPDR3_0); // Pull-Up
}

void DMA_PingPong_Init(void) {
    RCC->AHB1ENR |= RCC_AHB1ENR_DMA2EN;

    DMA2_Stream0->CR &= ~DMA_SxCR_EN;
    while(DMA2_Stream0->CR & DMA_SxCR_EN);

    // DMA2_Stream0->PAR = (uint32_t)&(PERIPHERAL->DR); // Point this to your ADC/UART later
    DMA2_Stream0->M0AR = (uint32_t)buffer_A;
    DMA2_Stream0->M1AR = (uint32_t)buffer_B;
    DMA2_Stream0->NDTR = BUFFER_SIZE;

    DMA2_Stream0->CR = 0;
    DMA2_Stream0->CR |= DMA_SxCR_CIRC | DMA_SxCR_DBM | DMA_SxCR_MINC | DMA_SxCR_TCIE | DMA_SxCR_HTIE;

    NVIC_EnableIRQ(DMA2_Stream0_IRQn);
    // DMA2_Stream0->CR |= DMA_SxCR_EN; // Uncomment when you connect your sensor
}

void SystemClock_Config(void) {
    RCC->CR |= RCC_CR_HSEON;
    while (!(RCC->CR & RCC_CR_HSERDY));

    RCC->APB1ENR |= RCC_APB1ENR_PWREN;
    PWR->CR |= PWR_CR_VOS;

    FLASH->ACR = FLASH_ACR_ICEN | FLASH_ACR_DCEN | FLASH_ACR_PRFTEN | FLASH_ACR_LATENCY_5WS;
    RCC->CFGR |= RCC_CFGR_HPRE_DIV1 | RCC_CFGR_PPRE1_DIV4 | RCC_CFGR_PPRE2_DIV2;

    uint32_t pll_m = 8, pll_n = 336, pll_p = 0, pll_q = 7;
    RCC->PLLCFGR = (pll_m) | (pll_n << 6) | (pll_p << 16) | RCC_PLLCFGR_PLLSRC_HSE | (pll_q << 24);

    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY));

    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |= RCC_CFGR_SW_PLL;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL);

    SystemCoreClock = 168000000;
}

void SysTick_Init(void) {
    SysTick_Config(SystemCoreClock / 1000);
}

// ====================================================================
// INTERRUPTS & DELAYS
// ====================================================================
void SysTick_Handler(void) {
    msTicks++;
}

void Delay_ms(uint32_t ms) {
    uint32_t startTicks = msTicks;
    while ((msTicks - startTicks) < ms);
}

void DMA2_Stream0_IRQHandler(void) {
    // Half Transfer (Buffer A is full)
    if (DMA2->LISR & DMA_LISR_HTIF0) {
        DMA2->LIFCR |= DMA_LIFCR_CHTIF0;
        buffer_A_full = 1;
    }

    // Transfer Complete (Buffer B is full)
    if (DMA2->LISR & DMA_LISR_TCIF0) {
        DMA2->LIFCR |= DMA_LIFCR_CTCIF0;
        buffer_B_full = 1;
    }
}

// ====================================================================
// MAIN APPLICATION
// ====================================================================
int main(void)
{
    SystemClock_Config();
    SysTick_Init();
    GPIO_Init();
    DMA_PingPong_Init();

    // Enable the clock for the USB OTG FS peripheral (AHB2 Bus)
    RCC->AHB2ENR |= RCC_AHB2ENR_OTGFSEN;
    Delay_ms(10); // Give the silicon a tiny moment to power up

    // Initialize the TinyUSB Host Stack
    tusb_init();

    while (1)
    {
        // 1. Keep the USB stack alive
        tuh_task();

        // 2. Only run file system logic if the USB is connected AND fully awake!
        if (live_usb_connected == 1 && tuh_msc_ready(usb_dev_addr)) {

            // Mount the drive (0 = Delayed mount, much safer for slow drives!)
            if (live_drive_mounted == 0) {
                fres = f_mount(&usb_fs, "0:", 0);
                if (fres == FR_OK) {
                    live_drive_mounted = 1;
                    live_fatfs_error = 0;
                } else {
                    live_fatfs_error = fres;
                }
            }

            // Open or Create static.csv
            if (live_drive_mounted == 1 && live_file_created == 0) {
                fres = f_open(&log_file, "0:static.csv", FA_WRITE | FA_OPEN_APPEND);
                if (fres == FR_OK) {
                    live_file_created = 1;
                    live_fatfs_error = 0;
                } else {
                    live_fatfs_error = fres;
                }
            }

            // 3. Write Ping-Pong Buffers to USB
            if (live_file_created == 1) {
                UINT bytes_written;

                // Did DMA fill Buffer A?
                if (buffer_A_full == 1) {
                    buffer_A_full = 0;
                    fres = f_write(&log_file, buffer_A, BUFFER_SIZE, &bytes_written);

                    if (fres == FR_OK && bytes_written == BUFFER_SIZE) {
                        live_write_success = 1;
                        live_bytes_written += bytes_written;
                        f_sync(&log_file);
                    } else {
                        live_write_success = 0;
                        live_fatfs_error = fres;
                    }
                }

                // Did DMA fill Buffer B?
                if (buffer_B_full == 1) {
                    buffer_B_full = 0;
                    fres = f_write(&log_file, buffer_B, BUFFER_SIZE, &bytes_written);

                    if (fres == FR_OK && bytes_written == BUFFER_SIZE) {
                        live_write_success = 1;
                        live_bytes_written += bytes_written;
                        f_sync(&log_file);
                    } else {
                        live_write_success = 0;
                        live_fatfs_error = fres;
                    }
                }
            }
        }
    }
} // <--- End of main()

// ====================================================================
// TINYUSB & FATFS REQUIRED CALLBACKS
// ====================================================================

// TinyUSB Callback: Fired instantly when a USB drive is plugged in
void tuh_msc_mount_cb(uint8_t dev_addr) {
    usb_dev_addr = dev_addr; // Save the address
    live_usb_connected = 1;
}

// TinyUSB Callback: Fired instantly when a USB drive is pulled out
void tuh_msc_umount_cb(uint8_t dev_addr) {
    live_usb_connected = 0;
    usb_dev_addr = 0;      // Clear the address
    live_drive_mounted = 0;
    live_file_created = 0;
}

// Provide a dummy time for FatFs file timestamps
uint32_t get_fattime(void) {
    return 0; // Tells FatFs to use a default timestamp (Jan 1, 1980)
}

// Provide milliseconds to TinyUSB for timeouts
uint32_t tusb_time_millis_api(void) {
    return msTicks;
}

// The Hardware USB Interrupt Handler!
void OTG_FS_IRQHandler(void) {
    tuh_int_handler(0); // Pass the interrupt to TinyUSB Host Port 0
}
