#ifndef _TUSB_CONFIG_H_
#define _TUSB_CONFIG_H_

#ifdef __cplusplus
 extern "C" {
#endif

// 1. Tell TinyUSB we are using an STM32F4
#define CFG_TUSB_MCU               OPT_MCU_STM32F4

// 2. We are running Bare-Metal (No RTOS)
#define CFG_TUSB_OS                OPT_OS_NONE

// 3. Enable Host Mode
#define CFG_TUSB_RHPORT0_MODE      OPT_MODE_HOST

// 4. Memory alignment for DMA
#define CFG_TUSB_MEM_SECTION
#define CFG_TUSB_MEM_ALIGN         __attribute__ ((aligned(4)))

// 5. Enable Mass Storage Class (MSC) Host
#define CFG_TUH_MSC                1

// 6. Max devices and endpoints
#define CFG_TUH_DEVICE_MAX         1
#define CFG_TUH_ENUMERATION_BUFSIZE 256

#ifdef __cplusplus
 }
#endif

#endif /* _TUSB_CONFIG_H_ */
