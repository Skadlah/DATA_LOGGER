#ifndef DWC2_STM32_H_
#define DWC2_STM32_H_

#ifdef __cplusplus
extern "C" {
#endif

// 1. Link directly to your specific board header
#include "STM32F407VETx.h"

// 2. Hardcode endpoints and FIFO depths for STM32F4 Full-Speed
#define EP_MAX_FS       USB_OTG_FS_MAX_IN_ENDPOINTS
#define DFIFO_DEPTH_FS  320
#define DWC2_EP_MAX     EP_MAX_FS

// 3. Map the single Full-Speed controller
static const dwc2_controller_t _dwc2_controller[] = {
    { .reg_base = USB_OTG_FS_PERIPH_BASE, .irqnum = OTG_FS_IRQn, .ep_count = EP_MAX_FS, .otg_dfifo_depth = DFIFO_DEPTH_FS }
};

// 4. Clock and Interrupt Configurations
TU_ATTR_ALWAYS_INLINE static inline void dwc2_clock_init(uint8_t rhport, tusb_role_t role) {
  (void) rhport;
  (void) role;
}

TU_ATTR_ALWAYS_INLINE static inline void dwc2_int_set(uint8_t rhport, tusb_role_t role, bool enabled) {
  (void) role;
  const IRQn_Type irqn = (IRQn_Type) _dwc2_controller[rhport].irqnum;
  if (enabled) {
    NVIC_EnableIRQ(irqn);
  } else {
    NVIC_DisableIRQ(irqn);
  }
}

#define dwc2_dcd_int_enable(_rhport)  dwc2_int_set(_rhport, TUSB_ROLE_DEVICE, true)
#define dwc2_dcd_int_disable(_rhport) dwc2_int_set(_rhport, TUSB_ROLE_DEVICE, false)

TU_ATTR_ALWAYS_INLINE static inline void dwc2_remote_wakeup_delay(void) {
  uint32_t count = SystemCoreClock / 1000;
  while (count--) {
    __NOP();
  }
}

// 5. Bare-Metal STM32F4 PHY Init
static inline void dwc2_phy_init(dwc2_regs_t* dwc2, uint8_t hs_phy_type) {
    // Enable on-chip FS PHY
    dwc2->stm32_gccfg |= STM32_GCCFG_PWRDWN;
}

static inline void dwc2_phy_deinit(dwc2_regs_t* dwc2, uint8_t hs_phy_type) {
    // Disable on-chip FS PHY
    dwc2->stm32_gccfg &= ~STM32_GCCFG_PWRDWN;
}

// 6. Bus Turnaround Time Configuration
static inline void dwc2_phy_update(dwc2_regs_t* dwc2, uint8_t hs_phy_type) {
    uint32_t turnaround;

    if (SystemCoreClock >= 32000000u) { turnaround = 0x6u; }
    else if (SystemCoreClock >= 27500000u) { turnaround = 0x7u; }
    else if (SystemCoreClock >= 24000000u) { turnaround = 0x8u; }
    else if (SystemCoreClock >= 21800000u) { turnaround = 0x9u; }
    else if (SystemCoreClock >= 20000000u) { turnaround = 0xAu; }
    else if (SystemCoreClock >= 18500000u) { turnaround = 0xBu; }
    else if (SystemCoreClock >= 17200000u) { turnaround = 0xCu; }
    else if (SystemCoreClock >= 16000000u) { turnaround = 0xDu; }
    else if (SystemCoreClock >= 15000000u) { turnaround = 0xEu; }
    else { turnaround = 0xFu; }

    dwc2->gusbcfg = (dwc2->gusbcfg & ~GUSBCFG_TRDT_Msk) | (turnaround << GUSBCFG_TRDT_Pos);
}

// 7. GCCFG Configuration for STM32F4 VBUS Sensing
static inline void dwc2_stm32_gccfg_cfg(dwc2_regs_t* dwc2, bool vbus_sensing, bool is_host) {
  if (is_host) {
    vbus_sensing = false;
  }

  uint32_t gccfg = dwc2->stm32_gccfg;
  if (dwc2->guid < 0x2000) {
    if (is_host) {
      gccfg &= ~(STM32_GCCFG_NOVBUSSENS | STM32_GCCFG_VBUSBSEN | STM32_GCCFG_VBUSASEN);
    } else {
      if (vbus_sensing) {
        gccfg &= ~STM32_GCCFG_NOVBUSSENS;
        gccfg |= STM32_GCCFG_VBUSBSEN;
      } else {
        gccfg |= STM32_GCCFG_NOVBUSSENS;
        gccfg &= ~(STM32_GCCFG_VBUSBSEN | STM32_GCCFG_VBUSASEN);
      }
    }
  } else if (dwc2->guid < 0x5000) {
    if (vbus_sensing) {
      gccfg |= STM32_GCCFG_VBDEN;
    } else {
      gccfg &= ~STM32_GCCFG_VBDEN;
    }
  }

  dwc2->stm32_gccfg = gccfg;
}

#ifdef __cplusplus
}
#endif

#endif
