
#include "STM32F407VETx.h"

#ifndef __SYSTEM_STM32F4XX_H
#define __SYSTEM_STM32F4XX_H

#ifdef __cplusplus
 extern "C" {
#endif

#include <stdint.h>

/**
  * @brief System clock frequency (core clock)
  */
extern uint32_t SystemCoreClock;

/**
  * @brief AHB and APB prescaler tables
  */
extern const uint8_t  AHBPrescTable[16];
extern const uint8_t  APBPrescTable[8];

/**
  * @brief Setup the microcontroller system
  *        Initialize the FPU setting, vector table location and the PLL configuration is reset.
  */
extern void SystemInit(void);

/**
  * @brief Update SystemCoreClock variable according to Clock Register Values.
  */
extern void SystemCoreClockUpdate(void);

#ifdef __cplusplus
}
#endif

#endif /*__SYSTEM_STM32F4XX_H */
