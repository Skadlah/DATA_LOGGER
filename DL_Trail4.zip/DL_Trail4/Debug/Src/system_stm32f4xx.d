Src/system_stm32f4xx.o: ../Src/system_stm32f4xx.c \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/system_stm32f4xx.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/STM32F407VETx.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/core_cm4.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/cmsis_version.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/cmsis_compiler.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/cmsis_gcc.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/mpu_armv7.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/system_stm32f4xx.h
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/system_stm32f4xx.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/STM32F407VETx.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/core_cm4.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/cmsis_version.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/cmsis_compiler.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/cmsis_gcc.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/mpu_armv7.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/system_stm32f4xx.h:
