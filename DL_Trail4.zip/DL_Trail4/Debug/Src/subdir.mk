################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/diskio.c \
../Src/dwc2_common.c \
../Src/ff.c \
../Src/hcd_dwc2.c \
../Src/main.c \
../Src/syscalls.c \
../Src/sysmem.c \
../Src/system_stm32f4xx.c \
../Src/tusb.c \
../Src/tusb_fifo.c 

OBJS += \
./Src/diskio.o \
./Src/dwc2_common.o \
./Src/ff.o \
./Src/hcd_dwc2.o \
./Src/main.o \
./Src/syscalls.o \
./Src/sysmem.o \
./Src/system_stm32f4xx.o \
./Src/tusb.o \
./Src/tusb_fifo.o 

C_DEPS += \
./Src/diskio.d \
./Src/dwc2_common.d \
./Src/ff.d \
./Src/hcd_dwc2.d \
./Src/main.d \
./Src/syscalls.d \
./Src/sysmem.d \
./Src/system_stm32f4xx.d \
./Src/tusb.d \
./Src/tusb_fifo.d 


# Each subdirectory must supply rules for building sources it contributes
Src/%.o Src/%.su Src/%.cyclo: ../Src/%.c Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F4 -DSTM32F407VETx -c -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/class" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/host" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Src

clean-Src:
	-$(RM) ./Src/diskio.cyclo ./Src/diskio.d ./Src/diskio.o ./Src/diskio.su ./Src/dwc2_common.cyclo ./Src/dwc2_common.d ./Src/dwc2_common.o ./Src/dwc2_common.su ./Src/ff.cyclo ./Src/ff.d ./Src/ff.o ./Src/ff.su ./Src/hcd_dwc2.cyclo ./Src/hcd_dwc2.d ./Src/hcd_dwc2.o ./Src/hcd_dwc2.su ./Src/main.cyclo ./Src/main.d ./Src/main.o ./Src/main.su ./Src/syscalls.cyclo ./Src/syscalls.d ./Src/syscalls.o ./Src/syscalls.su ./Src/sysmem.cyclo ./Src/sysmem.d ./Src/sysmem.o ./Src/sysmem.su ./Src/system_stm32f4xx.cyclo ./Src/system_stm32f4xx.d ./Src/system_stm32f4xx.o ./Src/system_stm32f4xx.su ./Src/tusb.cyclo ./Src/tusb.d ./Src/tusb.o ./Src/tusb.su ./Src/tusb_fifo.cyclo ./Src/tusb_fifo.d ./Src/tusb_fifo.o ./Src/tusb_fifo.su

.PHONY: clean-Src

