Src/ff.o: ../Src/ff.c \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/ff.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/ffconf.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/diskio.h
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/ff.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/ffconf.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/diskio.h:
