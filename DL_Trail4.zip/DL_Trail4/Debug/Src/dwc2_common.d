Src/dwc2_common.o: ../Src/dwc2_common.c \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/tusb_option.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_compiler.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/tusb_config.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_mcu.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/dwc2_common.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_common.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_verify.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_types.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_debug.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/dwc2_type.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/host/hcd.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_common.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal/osal.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal/osal_none.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_fifo.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/dwc2_stm32.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/STM32F407VETx.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/core_cm4.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/cmsis_version.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/cmsis_compiler.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/cmsis_gcc.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/mpu_armv7.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/system_stm32f4xx.h
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/tusb_option.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_compiler.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/tusb_config.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_mcu.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/dwc2_common.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_common.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_verify.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_types.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_debug.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/dwc2_type.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/host/hcd.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_common.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal/osal.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal/osal_none.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_fifo.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/dwc2_stm32.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/STM32F407VETx.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/core_cm4.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/cmsis_version.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/cmsis_compiler.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/cmsis_gcc.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/mpu_armv7.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/system_stm32f4xx.h:
