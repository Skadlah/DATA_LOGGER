################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Inc/common/tusb_fifo.c 

OBJS += \
./Inc/common/tusb_fifo.o 

C_DEPS += \
./Inc/common/tusb_fifo.d 


# Each subdirectory must supply rules for building sources it contributes
Inc/common/%.o Inc/common/%.su Inc/common/%.cyclo: ../Inc/common/%.c Inc/common/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F4 -DSTM32F407VETx -c -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/class" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/host" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Inc-2f-common

clean-Inc-2f-common:
	-$(RM) ./Inc/common/tusb_fifo.cyclo ./Inc/common/tusb_fifo.d ./Inc/common/tusb_fifo.o ./Inc/common/tusb_fifo.su

.PHONY: clean-Inc-2f-common

