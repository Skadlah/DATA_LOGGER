Inc/host/hub.o: ../Inc/host/hub.c \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/tusb_option.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_compiler.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/tusb_config.h \
 C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_mcu.h
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/tusb_option.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_compiler.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/tusb_config.h:
C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common/tusb_mcu.h:
