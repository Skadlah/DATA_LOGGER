################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Inc/host/hub.c \
../Inc/host/usbh.c 

OBJS += \
./Inc/host/hub.o \
./Inc/host/usbh.o 

C_DEPS += \
./Inc/host/hub.d \
./Inc/host/usbh.d 


# Each subdirectory must supply rules for building sources it contributes
Inc/host/%.o Inc/host/%.su Inc/host/%.cyclo: ../Inc/host/%.c Inc/host/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F4 -DSTM32F407VETx -c -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/class" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/host" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Inc-2f-host

clean-Inc-2f-host:
	-$(RM) ./Inc/host/hub.cyclo ./Inc/host/hub.d ./Inc/host/hub.o ./Inc/host/hub.su ./Inc/host/usbh.cyclo ./Inc/host/usbh.d ./Inc/host/usbh.o ./Inc/host/usbh.su

.PHONY: clean-Inc-2f-host

