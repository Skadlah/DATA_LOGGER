################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Inc/class/net/ecm_rndis_device.c \
../Inc/class/net/ncm_device.c 

OBJS += \
./Inc/class/net/ecm_rndis_device.o \
./Inc/class/net/ncm_device.o 

C_DEPS += \
./Inc/class/net/ecm_rndis_device.d \
./Inc/class/net/ncm_device.d 


# Each subdirectory must supply rules for building sources it contributes
Inc/class/net/%.o Inc/class/net/%.su Inc/class/net/%.cyclo: ../Inc/class/net/%.c Inc/class/net/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F4 -DSTM32F407VETx -c -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/class" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/host" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Inc-2f-class-2f-net

clean-Inc-2f-class-2f-net:
	-$(RM) ./Inc/class/net/ecm_rndis_device.cyclo ./Inc/class/net/ecm_rndis_device.d ./Inc/class/net/ecm_rndis_device.o ./Inc/class/net/ecm_rndis_device.su ./Inc/class/net/ncm_device.cyclo ./Inc/class/net/ncm_device.d ./Inc/class/net/ncm_device.o ./Inc/class/net/ncm_device.su

.PHONY: clean-Inc-2f-class-2f-net

