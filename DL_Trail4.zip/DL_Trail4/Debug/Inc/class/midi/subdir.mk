################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Inc/class/midi/midi_device.c \
../Inc/class/midi/midi_host.c 

OBJS += \
./Inc/class/midi/midi_device.o \
./Inc/class/midi/midi_host.o 

C_DEPS += \
./Inc/class/midi/midi_device.d \
./Inc/class/midi/midi_host.d 


# Each subdirectory must supply rules for building sources it contributes
Inc/class/midi/%.o Inc/class/midi/%.su Inc/class/midi/%.cyclo: ../Inc/class/midi/%.c Inc/class/midi/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F4 -DSTM32F407VETx -c -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/class" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/host" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Inc-2f-class-2f-midi

clean-Inc-2f-class-2f-midi:
	-$(RM) ./Inc/class/midi/midi_device.cyclo ./Inc/class/midi/midi_device.d ./Inc/class/midi/midi_device.o ./Inc/class/midi/midi_device.su ./Inc/class/midi/midi_host.cyclo ./Inc/class/midi/midi_host.d ./Inc/class/midi/midi_host.o ./Inc/class/midi/midi_host.su

.PHONY: clean-Inc-2f-class-2f-midi

