################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Inc/class/cdc/cdc_device.c \
../Inc/class/cdc/cdc_host.c 

OBJS += \
./Inc/class/cdc/cdc_device.o \
./Inc/class/cdc/cdc_host.o 

C_DEPS += \
./Inc/class/cdc/cdc_device.d \
./Inc/class/cdc/cdc_host.d 


# Each subdirectory must supply rules for building sources it contributes
Inc/class/cdc/%.o Inc/class/cdc/%.su Inc/class/cdc/%.cyclo: ../Inc/class/cdc/%.c Inc/class/cdc/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F4 -DSTM32F407VETx -c -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/class" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/host" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Inc-2f-class-2f-cdc

clean-Inc-2f-class-2f-cdc:
	-$(RM) ./Inc/class/cdc/cdc_device.cyclo ./Inc/class/cdc/cdc_device.d ./Inc/class/cdc/cdc_device.o ./Inc/class/cdc/cdc_device.su ./Inc/class/cdc/cdc_host.cyclo ./Inc/class/cdc/cdc_host.d ./Inc/class/cdc/cdc_host.o ./Inc/class/cdc/cdc_host.su

.PHONY: clean-Inc-2f-class-2f-cdc

