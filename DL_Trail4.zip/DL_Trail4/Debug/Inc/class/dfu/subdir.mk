################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Inc/class/dfu/dfu_device.c \
../Inc/class/dfu/dfu_rt_device.c 

OBJS += \
./Inc/class/dfu/dfu_device.o \
./Inc/class/dfu/dfu_rt_device.o 

C_DEPS += \
./Inc/class/dfu/dfu_device.d \
./Inc/class/dfu/dfu_rt_device.d 


# Each subdirectory must supply rules for building sources it contributes
Inc/class/dfu/%.o Inc/class/dfu/%.su Inc/class/dfu/%.cyclo: ../Inc/class/dfu/%.c Inc/class/dfu/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F4 -DSTM32F407VETx -c -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/class" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/host" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Inc-2f-class-2f-dfu

clean-Inc-2f-class-2f-dfu:
	-$(RM) ./Inc/class/dfu/dfu_device.cyclo ./Inc/class/dfu/dfu_device.d ./Inc/class/dfu/dfu_device.o ./Inc/class/dfu/dfu_device.su ./Inc/class/dfu/dfu_rt_device.cyclo ./Inc/class/dfu/dfu_rt_device.d ./Inc/class/dfu/dfu_rt_device.o ./Inc/class/dfu/dfu_rt_device.su

.PHONY: clean-Inc-2f-class-2f-dfu

