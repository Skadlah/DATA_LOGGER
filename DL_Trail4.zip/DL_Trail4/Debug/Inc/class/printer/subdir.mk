################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Inc/class/printer/printer_device.c 

OBJS += \
./Inc/class/printer/printer_device.o 

C_DEPS += \
./Inc/class/printer/printer_device.d 


# Each subdirectory must supply rules for building sources it contributes
Inc/class/printer/%.o Inc/class/printer/%.su Inc/class/printer/%.cyclo: ../Inc/class/printer/%.c Inc/class/printer/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F4 -DSTM32F407VETx -c -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/class" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/host" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Inc-2f-class-2f-printer

clean-Inc-2f-class-2f-printer:
	-$(RM) ./Inc/class/printer/printer_device.cyclo ./Inc/class/printer/printer_device.d ./Inc/class/printer/printer_device.o ./Inc/class/printer/printer_device.su

.PHONY: clean-Inc-2f-class-2f-printer

