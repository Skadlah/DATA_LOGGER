################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Inc/class/msc/msc_device.c \
../Inc/class/msc/msc_host.c 

OBJS += \
./Inc/class/msc/msc_device.o \
./Inc/class/msc/msc_host.o 

C_DEPS += \
./Inc/class/msc/msc_device.d \
./Inc/class/msc/msc_host.d 


# Each subdirectory must supply rules for building sources it contributes
Inc/class/msc/%.o Inc/class/msc/%.su Inc/class/msc/%.cyclo: ../Inc/class/msc/%.c Inc/class/msc/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F4 -DSTM32F407VETx -c -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/class" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/osal" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/host" -I"C:/Users/Milind/STM32CubeIDE/workspace_2.1.0/DL_Trail4/Inc/common" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Inc-2f-class-2f-msc

clean-Inc-2f-class-2f-msc:
	-$(RM) ./Inc/class/msc/msc_device.cyclo ./Inc/class/msc/msc_device.d ./Inc/class/msc/msc_device.o ./Inc/class/msc/msc_device.su ./Inc/class/msc/msc_host.cyclo ./Inc/class/msc/msc_host.d ./Inc/class/msc/msc_host.o ./Inc/class/msc/msc_host.su

.PHONY: clean-Inc-2f-class-2f-msc

