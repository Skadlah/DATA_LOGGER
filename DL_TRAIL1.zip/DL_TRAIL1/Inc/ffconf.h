
#define FFCONF_DEF	80286	/* Revision ID - MUST MATCH ff.h */

#define FF_CODE_PAGE 	   437

#define FF_FS_READONLY     0    // We need WRITE capability
#define FF_FS_MINIMIZE     0    // Full features
#define FF_USE_FIND        0    // Not needed
#define FF_USE_MKFS        0    // Not needed
#define FF_USE_FASTSEEK    0    // Not needed
#define FF_USE_EXPAND      0    // Not needed
#define FF_USE_CHMOD       0    // Not needed
#define FF_USE_LABEL       0    // Not needed
#define FF_USE_FORWARD     0    // Not needed

#define FF_USE_STRFUNC     0    // String functions not needed
#define FF_PRINT_LLI       0    // Not using f_printf with long long
#define FF_PRINT_FLOAT     0    // Not using float
#define FF_STRF_ENCODE     0

#define FF_FS_LOCK         0    // No file locking needed
#define FF_FS_REENTRANT    0    // No RTOS
#define FF_FS_TIMEOUT      1000
#define FF_SYNC_t          HANDLE

#define FF_VOLUMES         1    // Single USB drive
#define FF_STR_VOLUME_ID   0
#define FF_VOLUME_STRS     "RAM","NAND","CF","SD","SD2","USB","USB2","USB3"

#define FF_MULTI_PARTITION 0    // Single partition

#define FF_MIN_SS          512
#define FF_MAX_SS          512  // USB mass storage uses 512 byte sectors

#define FF_LBA64           0
#define FF_MIN_GPT         0

#define FF_USE_TRIM        0

#define FF_FS_TINY         0    // 0 = Better performance (larger buffer)
// #define FF_FS_TINY      1    // 1 = Lower RAM usage (slower)

#define FF_FS_EXFAT        0    // FAT32 only (simpler)
#define FF_FS_NORTC        1    // No real-time clock
#define FF_NORTC_MON       1
#define FF_NORTC_MDAY      1
#define FF_NORTC_YEAR      2024

#define FF_FS_NOFSINFO     0

#define FF_FS_READONLY     0
#define FF_FS_MINIMIZE     0

#define FF_USE_LFN         0    // Disable long filenames (saves RAM)
#define FF_LFN_UNICODE     0
#define FF_LFN_BUF         255
#define FF_SFN_BUF         12

#define FF_USE_FASTSEEK    0
