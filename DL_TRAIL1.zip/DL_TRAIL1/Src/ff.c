/*
 * ff.c
 *
 *  Created on: 15-Apr-2026
 *      Author: Milind
 */

/*----------------------------------------------------------------------------/
/  FatFs - Generic FAT Filesystem Module  R0.15 - Minimal Version             /
/  Customized for: STM32F407 Bare-Metal USB Datalogger                        /
/-----------------------------------------------------------------------------*/

#include "ff.h"			/* Declarations of FatFs API */
#include "diskio.h"		/* Declarations of device I/O functions */
#include <stddef.h>
#include <string.h>


/*---------------------------------------------------------------------------*/
/* Private Definitions                                                        */
/*---------------------------------------------------------------------------*/

/* FAT types */
#define FS_FAT12	1
#define FS_FAT16	2
#define FS_FAT32	3

/* File attribute bits for directory entry */
#define AM_RDO	0x01	/* Read only */
#define AM_HID	0x02	/* Hidden */
#define AM_SYS	0x04	/* System */
#define AM_DIR	0x10	/* Directory */
#define AM_ARC	0x20	/* Archive */

/* FAT32 FSInfo sector signature */
#define FSINFO_SIG1	0x41615252
#define FSINFO_SIG2	0x61417272

/*---------------------------------------------------------------------------*/
/* Private Macros                                                             */
/*---------------------------------------------------------------------------*/

/* Get cluster number from FAT entry */
#define GET_FATENTRY(fs, clst)	((fs)->fs_type == FS_FAT32 ? \
	(ld_dword((fs)->win + (((clst) * 4) % SS(fs))) & 0x0FFFFFFF) : \
	((fs)->fs_type == FS_FAT16 ? \
	ld_word((fs)->win + (((clst) * 2) % SS(fs))) : \
	((ld_word((fs)->win + (((clst) * 3) / 2 % SS(fs))) >> (((clst) & 1) * 4)) & 0x0FFF)))

/* Put cluster number into FAT entry */
#define PUT_FATENTRY(fs, clst, val) do { \
	if ((fs)->fs_type == FS_FAT32) { \
		st_dword((fs)->win + (((clst) * 4) % SS(fs)), (DWORD)(val)); \
	} else if ((fs)->fs_type == FS_FAT16) { \
		st_word((fs)->win + (((clst) * 2) % SS(fs)), (WORD)(val)); \
	} else { \
		WORD w = ld_word((fs)->win + (((clst) * 3) / 2 % SS(fs))); \
		if ((clst) & 1) w = (w & 0x000F) | ((WORD)(val) << 4); \
		else w = (w & 0xFFF0) | ((WORD)(val) & 0x0FFF); \
		st_word((fs)->win + (((clst) * 3) / 2 % SS(fs)), w); \
	} \
} while (0)

/* Sector size */
#define SS(fs)	512U

/*---------------------------------------------------------------------------*/
/* Private Helper Functions                                                   */
/*---------------------------------------------------------------------------*/

static WORD ld_word (const BYTE* ptr)	/* Load a 16-bit little-endian word */
{
	return (WORD)(ptr[1] << 8) | ptr[0];
}

static DWORD ld_dword (const BYTE* ptr)	/* Load a 32-bit little-endian dword */
{
	return (DWORD)ld_word(ptr + 2) << 16 | ld_word(ptr);
}

static void st_word (BYTE* ptr, WORD val)	/* Store a 16-bit word in little-endian */
{
	ptr[0] = (BYTE)val;
	ptr[1] = (BYTE)(val >> 8);
}

static void st_dword (BYTE* ptr, DWORD val)	/* Store a 32-bit dword in little-endian */
{
	st_word(ptr, (WORD)val);
	st_word(ptr + 2, (WORD)(val >> 16));
}

/*---------------------------------------------------------------------------*/
/* Filesystem Mount/Unmount                                                   */
/*---------------------------------------------------------------------------*/

FRESULT f_mount (
	FATFS* fs,			/* Pointer to the filesystem object */
	const TCHAR* path,	/* Logical drive number */
	BYTE opt			/* Initialization option */
)
{
	BYTE fmt, pdrv;
	BYTE buf[36];
	DWORD volbase, fatsize, dirbase, database, n_fatent;
	FRESULT res;

	(void)opt;  /* Suppress unused warning */
	(void)fmt;  /* Suppress unused warning */
	(void)dirbase;  /* Suppress unused warning */
	(void)database;  /* Suppress unused warning */
	(void)res;  /* Suppress unused warning */

	if (!fs) {
		/* Unmount: f_mount(NULL, "0:", 0) */
		return FR_OK;
	}

	/* Get physical drive number from path ("0:" -> pdrv=0) */
	pdrv = path[0] - '0';
	fs->pdrv = pdrv;

	/* Initialize the disk drive */
	if (disk_initialize(pdrv) & STA_NOINIT) {
		return FR_NOT_READY;
	}

	/* Read boot sector (sector 0) */
	if (disk_read(pdrv, buf, 0, 1) != RES_OK) {
		return FR_DISK_ERR;
	}

	/* Check boot signature
	if (buf[510] != 0x55 || buf[511] != 0xAA) {
		return FR_NO_FILESYSTEM;
	}*/

	/* Parse BPB (BIOS Parameter Block) */
	fs->csize = buf[13];				/* Sectors per cluster */
	fs->n_rootdir = ld_word(buf + 17);	/* Number of root directory entries */
	volbase = 0;

	fatsize = ld_word(buf + 22);		/* Sectors per FAT */
	if (fatsize == 0) {
		/* FAT32 */
		fatsize = ld_dword(buf + 36);
		volbase = ld_dword(buf + 28);	/* Root directory cluster */
		fs->n_fats = buf[16];
		fs->fs_type = FS_FAT32;
	} else {
		/* FAT12/16 */
		fs->n_fats = buf[16];
		fs->fs_type = FS_FAT16;
	}

	/* Calculate filesystem geometry */
	fs->fatbase = ld_word(buf + 14);	/* Reserved sectors */
	fs->database = fs->fatbase + fs->n_fats * fatsize;

	if (fs->fs_type == FS_FAT32) {
		fs->dirbase = fs->database + (volbase - 2) * fs->csize;
	} else {
		fs->dirbase = fs->database;
		fs->database += (fs->n_rootdir * 32 + 511) / 512;
	}

	/* Calculate number of FAT entries (clusters) */
	n_fatent = (ld_dword(buf + 32) ? ld_dword(buf + 32) : ld_word(buf + 19)) - fs->database;
	fs->n_fatent = n_fatent / fs->csize + 2;
	fs->fsize = fatsize;
	fs->volbase = volbase;
	fs->free_clst = 0xFFFFFFFF;
	fs->wflag = 0;
	fs->id = 1;

	fs->fs_type = (BYTE)fs->fs_type;
	return FR_OK;
}

/*---------------------------------------------------------------------------*/
/* Open/Create a File                                                         */
/*---------------------------------------------------------------------------*/

FRESULT f_open (
	FIL* fp,			/* Pointer to the blank file object */
	const TCHAR* path,	/* Pointer to the file name */
	BYTE mode			/* Access mode and open method flags */
)
{
	FATFS* fs;
	BYTE pdrv;
	BYTE dir_buf[512];  /* Changed to 512 bytes for full sector */
	DWORD clst;
	FRESULT res;

	(void)res;  /* Suppress unused warning */

	/* Get drive number from path */
	pdrv = path[0] - '0';

	/* Get filesystem object */
	extern FATFS USBHFatFS;
	fs = &USBHFatFS;

	if (!fs || fs->fs_type == 0) {
		return FR_NOT_READY;
	}

	/* Search for file in root directory - Scan ALL sectors */
	DWORD root_sectors = (fs->n_rootdir * 32 + 511) / 512;
	BYTE found_empty = 0;

	for (DWORD sect = 0; sect < root_sectors; sect++) {
		if (disk_read(pdrv, dir_buf, fs->dirbase + sect, 1) != RES_OK) {
			return FR_DISK_ERR;
		}

		for (int i = 0; i < 512; i += 32) {
			BYTE* de = dir_buf + i;

			if (de[0] == 0x00) {
				/* End of directory */
				goto create_file;
			}

			if (de[0] == 0xE5) {
				/* Empty slot */
				if (!found_empty) {
					fp->dir_sect = fs->dirbase + sect;
					fp->dir_ptr = de;
					found_empty = 1;
				}
				continue;
			}

			/* Check for "LOG     CSV" (8.3 format) */
			if (de[0] == 'L' && de[1] == 'O' && de[2] == 'G' &&
				de[8] == 'C' && de[9] == 'S' && de[10] == 'V') {

				if (mode & FA_CREATE_ALWAYS) {
					/* Delete existing file */
					de[0] = 0xE5;
					goto create_file;
				} else {
					/* Open existing file */
					fp->obj.sclust = ld_word(de + 20);
					fp->obj.sclust |= (DWORD)ld_word(de + 26) << 16;
					fp->obj.objsize = ld_dword(de + 28);
					fp->fptr = 0;
					fp->flag = mode;
					fp->err = 0;
					fp->obj.fs = fs;
					fp->obj.id = fs->id;
					fp->dir_sect = fs->dirbase + sect;
					fp->dir_ptr = de;
					return FR_OK;
				}
			}
		}
	}

create_file:
	/* Create new file */
	if (!(mode & (FA_CREATE_ALWAYS | FA_CREATE_NEW | FA_OPEN_ALWAYS))) {
		return FR_NO_FILE;
	}

	if (!found_empty) {
		return FR_DENIED;
	}

	/* Allocate first cluster */
	clst = 2;
	for (; clst < fs->n_fatent; clst++) {
		if (disk_read(pdrv, fs->win, fs->fatbase + (clst * 4) / 512, 1) != RES_OK) {
			return FR_DISK_ERR;
		}
		if (GET_FATENTRY(fs, clst) == 0) {
			PUT_FATENTRY(fs, clst, 0x0FFFFFFF);
			fs->wflag = 1;
			break;
		}
	}

	if (clst >= fs->n_fatent) {
		return FR_DENIED;
	}

	/* Create directory entry */
	BYTE* de = fp->dir_ptr;

	const char* name = "LOG     CSV";
	for (int i = 0; i < 11; i++) {
		de[i] = name[i];
	}

	de[11] = AM_ARC;
	de[12] = 0;
	de[13] = 0;
	st_word(de + 14, 0);
	st_word(de + 16, 0);
	st_word(de + 18, 0);
	st_word(de + 20, (WORD)clst);
	st_word(de + 22, 0);
	st_word(de + 24, 0);
	st_word(de + 26, (WORD)(clst >> 16));
	st_dword(de + 28, 0);

	if (disk_write(pdrv, dir_buf, fp->dir_sect, 1) != RES_OK) {
		return FR_DISK_ERR;
	}

	fp->obj.sclust = clst;
	fp->obj.objsize = 0;
	fp->fptr = 0;
	fp->flag = mode;
	fp->err = 0;
	fp->obj.fs = fs;
	fp->obj.id = fs->id;

	return FR_OK;
}

/*---------------------------------------------------------------------------*/
/* Read File                                                                  */
/*---------------------------------------------------------------------------*/

FRESULT f_read (
	FIL* fp,		/* Pointer to the file object */
	void* buff,		/* Pointer to data buffer */
	UINT btr,		/* Number of bytes to read */
	UINT* br		/* Pointer to number of bytes read */
)
{
	DWORD clst, sect, remain;
	UINT rcnt = 0;
	BYTE pdrv;
	FATFS* fs;

	*br = 0;
	if (!fp || !fp->obj.fs) return FR_INVALID_OBJECT;

	fs = fp->obj.fs;
	pdrv = fs->pdrv;

	if (fp->fptr >= fp->obj.objsize) return FR_OK;
	if (btr > fp->obj.objsize - fp->fptr) btr = (UINT)(fp->obj.objsize - fp->fptr);

	/* Convert file pointer to cluster and sector */
	clst = fp->obj.sclust;
	sect = fs->database + (clst - 2) * fs->csize + (fp->fptr / 512) % fs->csize;

	/* Read sectors */
	while (btr) {
		remain = 512 - (fp->fptr % 512);
		if (remain > btr) remain = btr;

		if (disk_read(pdrv, (BYTE*)buff + rcnt, sect, 1) != RES_OK) {
			return FR_DISK_ERR;
		}

		fp->fptr += remain;
		rcnt += remain;
		btr -= remain;

		if (btr && (fp->fptr % 512) == 0) {
			sect++;
		}
	}

	*br = rcnt;
	return FR_OK;
}

/*---------------------------------------------------------------------------*/
/* Write File                                                                 */
/*---------------------------------------------------------------------------*/

FRESULT f_write (
	FIL* fp,			/* Pointer to the file object */
	const void* buff,	/* Pointer to the data to be written */
	UINT btw,			/* Number of bytes to write */
	UINT* bw			/* Pointer to number of bytes written */
)
{
	DWORD clst, sect;
	UINT wcnt = 0;
	BYTE pdrv;
	FATFS* fs;
	BYTE sector_buf[512];

	*bw = 0;
	if (!fp || !fp->obj.fs) return FR_INVALID_OBJECT;

	fs = fp->obj.fs;
	pdrv = fs->pdrv;

	/* Convert file pointer to cluster and sector */
	clst = fp->obj.sclust;
	sect = fs->database + (clst - 2) * fs->csize + (fp->fptr / 512) % fs->csize;

	/* Read-modify-write for partial sector */
	if (fp->fptr % 512) {
		disk_read(pdrv, sector_buf, sect, 1);
	}

	while (btw) {
		UINT remain = 512 - (fp->fptr % 512);
		if (remain > btw) remain = btw;

		/* Copy data to sector buffer */
		if (fp->fptr % 512 == 0) {
			/* Full sector write */
			for (UINT i = 0; i < remain; i++) {
				sector_buf[i] = ((BYTE*)buff)[wcnt + i];
			}
		} else {
			/* Partial sector - preserve existing data */
			for (UINT i = 0; i < remain; i++) {
				sector_buf[(fp->fptr % 512) + i] = ((BYTE*)buff)[wcnt + i];
			}
		}

		/* Write sector */
		if (disk_write(pdrv, sector_buf, sect, 1) != RES_OK) {
			return FR_DISK_ERR;
		}

		fp->fptr += remain;
		wcnt += remain;
		btw -= remain;

		if (btw) {
			sect++;
		}
	}

	/* Update file size */
	if (fp->fptr > fp->obj.objsize) {
		fp->obj.objsize = fp->fptr;
	}

	*bw = wcnt;
	return FR_OK;
}

/*---------------------------------------------------------------------------*/
/* Close File                                                                 */
/*---------------------------------------------------------------------------*/

FRESULT f_close (
	FIL* fp		/* Pointer to the file object */
)
{
	FATFS* fs;
	BYTE pdrv;
	BYTE dir_buf[512];

	if (!fp || !fp->obj.fs) return FR_INVALID_OBJECT;

	fs = fp->obj.fs;
	pdrv = fs->pdrv;

	/* Update directory entry with final file size */
	disk_read(pdrv, dir_buf, fp->dir_sect, 1);
	BYTE* de = fp->dir_ptr;
	st_dword(de + 28, fp->obj.objsize);
	st_word(de + 22, 0);	/* Update time */
	st_word(de + 24, 0);	/* Update date */
	disk_write(pdrv, dir_buf, fp->dir_sect, 1);

	fp->obj.fs = NULL;
	return FR_OK;
}

/*---------------------------------------------------------------------------*/
/* Stub Functions (Not Used in This Project)                                  */
/*---------------------------------------------------------------------------*/

FRESULT f_lseek (FIL* fp, FSIZE_t ofs)
{
	(void)fp; (void)ofs;
	return FR_OK;
}

FRESULT f_sync (FIL* fp)
{
	(void)fp;
	return FR_OK;
}

FRESULT f_opendir (DIR* dp, const TCHAR* path)
{
	(void)dp; (void)path;
	return FR_OK;
}

FRESULT f_closedir (DIR* dp)
{
	(void)dp;
	return FR_OK;
}

FRESULT f_readdir (DIR* dp, FILINFO* fno)
{
	(void)dp; (void)fno;
	return FR_OK;
}

FRESULT f_stat (const TCHAR* path, FILINFO* fno)
{
	(void)path; (void)fno;
	return FR_OK;
}

FRESULT f_getfree (const TCHAR* path, DWORD* nclst, FATFS** fatfs)
{
	(void)path; (void)nclst; (void)fatfs;
	return FR_OK;
}

FRESULT f_unlink (const TCHAR* path)
{
	(void)path;
	return FR_OK;
}

FRESULT f_mkdir (const TCHAR* path)
{
	(void)path;
	return FR_OK;
}

FRESULT f_chmod (const TCHAR* path, BYTE attr, BYTE mask)
{
	(void)path; (void)attr; (void)mask;
	return FR_OK;
}

FRESULT f_utime (const TCHAR* path, const FILINFO* fno)
{
	(void)path; (void)fno;
	return FR_OK;
}

FRESULT f_rename (const TCHAR* path_old, const TCHAR* path_new)
{
	(void)path_old; (void)path_new;
	return FR_OK;
}

FRESULT f_chdir (const TCHAR* path)
{
	(void)path;
	return FR_OK;
}

FRESULT f_chdrive (const TCHAR* path)
{
	(void)path;
	return FR_OK;
}

FRESULT f_getcwd (TCHAR* buff, UINT len)
{
	(void)buff; (void)len;
	return FR_OK;
}

FRESULT f_getlabel (const TCHAR* path, TCHAR* label, DWORD* vsn)
{
	(void)path; (void)label; (void)vsn;
	return FR_OK;
}

FRESULT f_setlabel (const TCHAR* label)
{
	(void)label;
	return FR_OK;
}

FRESULT f_truncate (FIL* fp)
{
	(void)fp;
	return FR_OK;
}

FRESULT f_mkfs (const TCHAR* path, const MKFS_PARM* opt, void* work, UINT len)
{
	(void)path; (void)opt; (void)work; (void)len;
	return FR_OK;
}

int f_putc (TCHAR c, FIL* fp)
{
	(void)c; (void)fp;
	return 0;
}

int f_puts (const TCHAR* str, FIL* fp)
{
	(void)str; (void)fp;
	return 0;
}

int f_printf (FIL* fp, const TCHAR* str, ...)
{
	(void)fp; (void)str;
	return 0;
}

TCHAR* f_gets (TCHAR* buff, int len, FIL* fp)
{
	(void)buff; (void)len; (void)fp;
	return NULL;
}
