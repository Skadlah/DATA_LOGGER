/*------------------------------------------------------------------------*/
/* Unicode handling functions for FatFs R0.15          --- > Library No Need to modified                   */
/*------------------------------------------------------------------------*/

#include "ff.h"

/*------------------------------------------------------------------------*/
/* Character code conversion tables                                       */
/*------------------------------------------------------------------------*/

#if FF_USE_LFN == 0
/* No LFN: Simple conversion */

WCHAR ff_convert (WCHAR src, UINT dir)
{
	if (src < 0x80) {	/* ASCII */
		return src;
	} else {
		return '?';		/* Unknown character */
	}
}

WCHAR ff_wtoupper (WCHAR chr)
{
	if (chr >= 'a' && chr <= 'z') return chr - 0x20;
	return chr;
}

#else
/* LFN enabled: Full conversion tables from ccsbcs.c or cc*.c */
/* The actual tables are in separate files included based on FF_CODE_PAGE */

#if FF_CODE_PAGE == 0
#error "FF_CODE_PAGE must be defined"
#endif

/* Include the SBCS/DBCS conversion table */
#if FF_CODE_PAGE < 900
#include "ccsbcs.c"
#elif FF_CODE_PAGE == 932
#include "cc932.c"
#elif FF_CODE_PAGE == 936
#include "cc936.c"
#elif FF_CODE_PAGE == 949
#include "cc949.c"
#elif FF_CODE_PAGE == 950
#include "cc950.c"
#else
#error "Unknown FF_CODE_PAGE"
#endif

WCHAR ff_convert (WCHAR src, UINT dir)
{
	const WORD *p;
	WORD c;
	DWORD i, n, idx;

	if (src < 0x80) {
		return src;
	}

	if (dir) {
		/* OEM to Unicode */
		p = Tbl;
		for (;;) {
			c = *p;
			if (c == 0) break;
			if (c == FF_CODE_PAGE) {
				p += 1;
				idx = src - 0x80;
				if (idx < 128) {
					return p[idx];
				}
				break;
			}
			p += 2 + 128;
		}
	} else {
		/* Unicode to OEM */
		p = Tbl;
		for (;;) {
			c = *p;
			if (c == 0) break;
			if (c == FF_CODE_PAGE) {
				p += 2;
				for (i = 0; i < 128; i++) {
					if (p[i] == src) {
						return (WCHAR)(i + 0x80);
					}
				}
				break;
			}
			p += 2 + 128;
		}
	}

	return '?';
}

WCHAR ff_wtoupper (WCHAR chr)
{
	if (chr >= 'a' && chr <= 'z') return chr - 0x20;

	/* Extended Latin */
	if (chr >= 0xE0 && chr <= 0xFF && chr != 0xF7) {
		return chr - 0x20;
	}

	/* Special cases */
	if (chr == 0x00FF) return 0x0178;  /* ÿ -> Ÿ */
	if (chr == 0x00DF) return 'S';     /* ß -> S (simplified) */

	return chr;
}

#endif /* FF_USE_LFN */
