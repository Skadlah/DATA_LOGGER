/*
 * diskio.c
 * Bare-Metal USB MSC interface for FatFs
 */

#include "ff.h"
#include "diskio.h"
#include <stdint.h>
#include <string.h>

/*=========================================================================*/
/* External USB State and Endpoints (from main.c)                          */
/*=========================================================================*/
extern volatile uint8_t usb_device_connected;
extern volatile uint8_t usb_msc_ready;
extern uint8_t msc_ep_out_addr;
extern uint8_t msc_ep_in_addr;

extern int USB_Bulk_Send(uint8_t ep_addr, uint8_t *data, uint16_t len);
extern int USB_Bulk_Receive(uint8_t ep_addr, uint8_t *data, uint16_t len);

/*=========================================================================*/
/* USB MSC Bulk-Only Transport (BOT) Definitions                           */
/*=========================================================================*/
#define CBW_SIGNATURE 0x43425355  /* "USBC" */
#define CSW_SIGNATURE 0x53425355  /* "USBS" */

/* Command Block Wrapper (31 bytes) */
typedef struct __attribute__((packed)) {
    uint32_t dCBWSignature;
    uint32_t dCBWTag;
    uint32_t dCBWDataTransferLength;
    uint8_t  bmCBWFlags;
    uint8_t  bCBWLUN;
    uint8_t  bCBWCBLength;
    uint8_t  CBWCB[16];
} MSC_CBW;

/* Command Status Wrapper (13 bytes) */
typedef struct __attribute__((packed)) {
    uint32_t dCSWSignature;
    uint32_t dCSWTag;
    uint32_t dCSWDataResidue;
    uint8_t  bCSWStatus;
} MSC_CSW;

/*=========================================================================*/
/* USB SCSI Command Wrapper                                                */
/*=========================================================================*/
int USB_SCSI_Command(uint8_t *cmd, uint8_t cmd_len, uint8_t direction, uint8_t *data, uint32_t data_len)
{
    MSC_CBW cbw;
    MSC_CSW csw;
    static uint32_t command_tag = 1;

    /* PHASE 1: COMMAND TRANSPORT */
    memset(&cbw, 0, sizeof(MSC_CBW));
    cbw.dCBWSignature = CBW_SIGNATURE;
    cbw.dCBWTag = command_tag;
    cbw.dCBWDataTransferLength = data_len;
    cbw.bmCBWFlags = direction;
    cbw.bCBWLUN = 0;
    cbw.bCBWCBLength = cmd_len;
    memcpy(cbw.CBWCB, cmd, cmd_len);

    if (USB_Bulk_Send(msc_ep_out_addr, (uint8_t*)&cbw, 31) != 0) {
        return -1;
    }

    /* PHASE 2: DATA TRANSPORT */
    if (data_len > 0) {
        if (direction == 0x80) { /* IN */
            if (USB_Bulk_Receive(msc_ep_in_addr, data, data_len) != 0) {
                return -2;
            }
        } else { /* OUT */
            if (USB_Bulk_Send(msc_ep_out_addr, data, data_len) != 0) {
                return -2;
            }
        }
    }

    /* PHASE 3: STATUS TRANSPORT */
    if (USB_Bulk_Receive(msc_ep_in_addr, (uint8_t*)&csw, 13) != 0) {
        return -3;
    }

    if (csw.dCSWSignature != CSW_SIGNATURE || csw.dCSWTag != command_tag || csw.bCSWStatus != 0) {
        return -4;
    }

    command_tag++;
    return 0;
}

/*=========================================================================*/
/* FatFs Disk I/O Interface                                                */
/*=========================================================================*/
#define SCSI_CMD_READ_10            0x28
#define SCSI_CMD_WRITE_10           0x2A
#define SCSI_DIR_IN                 0x80
#define SCSI_DIR_OUT                0x00

static uint32_t total_sectors = 0;
static uint16_t sector_size = 512;

DSTATUS disk_initialize (BYTE pdrv)
{
    if (pdrv != 0) return STA_NOINIT;
    if (!usb_device_connected || !usb_msc_ready) return STA_NOINIT;

    /* Assuming standard initialized state for testing */
    total_sectors = 1000000;
    return RES_OK;
}

DSTATUS disk_status (BYTE pdrv)
{
    if (pdrv != 0) return STA_NOINIT;
    if (!usb_device_connected || !usb_msc_ready) return STA_NOINIT;
    return RES_OK;
}

DRESULT disk_read (BYTE pdrv, BYTE *buff, LBA_t sector, UINT count)
{
    if (pdrv != 0 || !usb_msc_ready) return RES_NOTRDY;

    uint8_t scsi_cmd[10];

    scsi_cmd[0] = SCSI_CMD_READ_10;
    scsi_cmd[1] = 0x00;
    scsi_cmd[2] = (uint8_t)(sector >> 24);
    scsi_cmd[3] = (uint8_t)(sector >> 16);
    scsi_cmd[4] = (uint8_t)(sector >> 8);
    scsi_cmd[5] = (uint8_t)(sector);
    scsi_cmd[6] = 0x00;
    scsi_cmd[7] = (uint8_t)(count >> 8);
    scsi_cmd[8] = (uint8_t)(count);
    scsi_cmd[9] = 0x00;

    int result = USB_SCSI_Command(scsi_cmd, 10, SCSI_DIR_IN, buff, (count * 512));

    if (result == 0) return RES_OK;
    return RES_ERROR;
}

DRESULT disk_write (BYTE pdrv, const BYTE *buff, LBA_t sector, UINT count)
{
    if (pdrv != 0 || !usb_msc_ready) return RES_NOTRDY;

    uint8_t scsi_cmd[10];

    scsi_cmd[0] = SCSI_CMD_WRITE_10;
    scsi_cmd[1] = 0x00;
    scsi_cmd[2] = (uint8_t)(sector >> 24);
    scsi_cmd[3] = (uint8_t)(sector >> 16);
    scsi_cmd[4] = (uint8_t)(sector >> 8);
    scsi_cmd[5] = (uint8_t)(sector);
    scsi_cmd[6] = 0x00;
    scsi_cmd[7] = (uint8_t)(count >> 8);
    scsi_cmd[8] = (uint8_t)(count);
    scsi_cmd[9] = 0x00;

    /* Cast buff to non-const to pass to USB function */
    int result = USB_SCSI_Command(scsi_cmd, 10, SCSI_DIR_OUT, (uint8_t*)buff, (count * 512));

    if (result == 0) return RES_OK;
    return RES_ERROR;
}

DRESULT disk_ioctl (BYTE pdrv, BYTE cmd, void *buff)
{
    if (pdrv != 0) return RES_PARERR;
    if (!usb_msc_ready) return RES_NOTRDY;

    switch (cmd) {
        case CTRL_SYNC:
            return RES_OK;
        case GET_SECTOR_COUNT:
            *(DWORD *)buff = total_sectors;
            return RES_OK;
        case GET_SECTOR_SIZE:
            *(WORD *)buff = sector_size;
            return RES_OK;
        case GET_BLOCK_SIZE:
            *(DWORD *)buff = 1;
            return RES_OK;
        default:
            return RES_PARERR;
    }
}

#if FF_FS_NORTC == 1
DWORD get_fattime(void)
{
    /* Hardcoded: 2026-04-17 12:00:00 */
    return ((DWORD)(2026 - 1980) << 25) | ((DWORD)4 << 21) | ((DWORD)17 << 16) |
           ((DWORD)12 << 11) | ((DWORD)0 << 5) | ((DWORD)0 >> 1);
}
#endif
