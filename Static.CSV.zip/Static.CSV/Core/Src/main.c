/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : USB Host Mass Storage Datalogger
  *                   Target : STM32F407VGT
  *                   Storage: FAT32 USB Pendrive via OTG adapter
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"
#include "usb_host.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>   // for strlen()
/* USER CODE END Includes */

/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

// Defined in usb_host.c by CubeMX — tracks USB stack state machine
extern ApplicationTypeDef Appli_state;

// Defined in FATFS/App/fatfs.c by CubeMX — do NOT redefine, only extern
extern FATFS USBHFatFS;   // FatFs filesystem object
extern FIL   USBHFile;    // FatFs file object

// User flags — safe to define here
uint8_t is_pendrive_connected = 0;  // 1 = drive ready, 0 = no drive
uint8_t file_written          = 0;  // write-once guard per insertion
FRESULT fres;                       // FatFs return code

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
void MX_USB_HOST_Process(void);

/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_FATFS_Init();
  MX_USB_HOST_Init();

  /* USER CODE BEGIN 2 */
  /* USER CODE END 2 */

  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    // ----------------------------------------------------------------
    // 1. PUMP THE USB HOST STACK — must be called every loop iteration
    //    Handles enumeration, SOF packets, and state transitions
    // ----------------------------------------------------------------
    MX_USB_HOST_Process();

    // ----------------------------------------------------------------
    // 2. SYNC LOCAL FLAG WITH USB STACK STATE MACHINE
    //    APPLICATION_READY means FatFs can now access the drive
    // ----------------------------------------------------------------
    if (Appli_state == APPLICATION_READY)
    {
        is_pendrive_connected = 1;
    }
    else if (Appli_state == APPLICATION_DISCONNECT)
    {
        // Drive removed — reset both flags for next insertion
        is_pendrive_connected = 0;
        file_written          = 0;
    }
    else
    {
        is_pendrive_connected = 0;
    }

    // ----------------------------------------------------------------
    // 3. DATALOGGING BLOCK
    //    Runs ONCE per insertion, guarded by file_written flag
    // ----------------------------------------------------------------
    if (is_pendrive_connected && !file_written)
    {
        // --- 3a. Mount the FatFs volume ---
        // "0:/" = logical drive assigned to USB disk by CubeMX
        // Second arg '1' = mount immediately, not deferred
        fres = f_mount(&USBHFatFS, "0:/", 1);

        if (fres != FR_OK)
        {
            // FR_NOT_READY       = drive not fully enumerated yet, retry
            // FR_NO_FILESYSTEM   = pendrive not FAT32 formatted
            // FR_NOT_ENOUGH_CORE = heap too small, increase to 0x1000
            goto cleanup;
        }

        // --- 3b. Create / overwrite LOG.TXT ---
        // FA_CREATE_ALWAYS = create new, truncate if exists
        // FA_WRITE         = open for writing
        fres = f_open(&USBHFile, "0:/LOG.CSV",
                      FA_CREATE_ALWAYS | FA_WRITE);

        if (fres != FR_OK)
        {
            goto cleanup;
        }

        // --- 3c. Write the log string ---
        const char *log_msg = "Sr.No,Temp1,Temp2,sv1,sv2\r\n";
        UINT bytes_written    = 0;

        fres = f_write(&USBHFile,
                       log_msg,
                       strlen(log_msg),
                       &bytes_written);

        // Verify all bytes were written
        if ((fres != FR_OK) || (bytes_written != strlen(log_msg)))
        {
            // Partial write = disk full or write protected
            f_close(&USBHFile);
            goto cleanup;
        }

        // --- 3d. Close the file ---
        // CRITICAL: f_close() flushes write buffer and updates
        // directory entry with final file size.
        // Skipping this = 0 byte file on the drive!
        fres = f_close(&USBHFile);

        if (fres == FR_OK)
        {
            file_written = 1;  // Set guard — job done!
        }

    cleanup:
        // --- 3e. Unmount the volume ---
        // Always unmount to flush caches and allow safe removal
        f_mount(NULL, "0:/", 0);
    }

    // Small delay to prevent hammering the USB stack
    HAL_Delay(10);

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  // HSE + PLL → SYSCLK=96MHz, PLLQ=4 → USB gets 48MHz ✅
  RCC_OscInitStruct.OscillatorType      = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState            = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState        = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource       = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM            = 4;
  RCC_OscInitStruct.PLL.PLLN            = 96;
  RCC_OscInitStruct.PLL.PLLP            = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ            = 4;  // 96/4 = 24... see note below
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                   | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  */
static void MX_GPIO_Init(void)
{
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

/**
  * @brief  Error Handler
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1) {}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
